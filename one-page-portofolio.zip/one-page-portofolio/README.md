# One page portofolio

A Pen created on CodePen.io. Original URL: [https://codepen.io/raissaaz/pen/VwGPLNP](https://codepen.io/raissaaz/pen/VwGPLNP).

